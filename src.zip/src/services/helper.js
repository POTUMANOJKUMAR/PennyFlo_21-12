export const helper = {
  NotificationType: {
    payment: 1,
    transaction: 2,
    others: 3,
  },
};
